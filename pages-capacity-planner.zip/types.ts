export enum UserRole {
  PAGES = 'PAGES', // Formerly ADMIN (Can edit everything)
  STRATEGY = 'STRATEGY' // Formerly VIEWER (Can request)
}

export enum TicketStatus {
  BACKLOG = 'BACKLOG',
  TODO = 'TODO',
  IN_PROGRESS = 'IN_PROGRESS',
  DONE = 'DONE'
}

export enum Region {
  DOMESTIC = 'DOMESTIC', // 國內
  OVERSEAS = 'OVERSEAS'  // 海外
}

export interface Sprint {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  capacityDomestic: number;
  capacityOverseas: number;
  isClosed: boolean;
  isHidden?: boolean; // New: Support for hiding columns
}

export interface Ticket {
  id: string;
  title: string;
  jiraLink: string; // Changed from description
  // requester field removed
  points: number;
  sprintId: string | null; // null if in backlog
  status: TicketStatus;
  createdAt: string;
  
  // New Fields
  region: Region;
  order?: number; // For manual sorting
  
  // Planning Fields
  strategyPlan?: string; // 策略PM規劃
  pagesPlan?: string; // PAGEs規劃
  
  // Dates
  desiredReleaseDate?: string; // 期望上線日 (User Input)
  
  // Visibility
  isHidden?: boolean; // New: For hiding tickets instead of deleting
}

export interface AppState {
  sprints: Sprint[];
  tickets: Ticket[];
  currentUserRole: UserRole;
}