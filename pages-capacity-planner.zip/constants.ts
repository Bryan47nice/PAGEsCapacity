import { Sprint, Ticket, TicketStatus, Region } from "./types";

export const MOCK_SPRINTS: Sprint[] = [
  {
    id: 'sprint-1',
    name: 'Sprint 24-05 (Current)',
    startDate: '2024-05-01',
    endDate: '2024-05-14',
    capacityDomestic: 15,
    capacityOverseas: 10,
    isClosed: false,
    isHidden: false,
  },
  {
    id: 'sprint-2',
    name: 'Sprint 24-06',
    startDate: '2024-05-15',
    endDate: '2024-05-28',
    capacityDomestic: 15,
    capacityOverseas: 10,
    isClosed: false,
    isHidden: false,
  },
  {
    id: 'sprint-3',
    name: 'Sprint 24-07',
    startDate: '2024-05-29',
    endDate: '2024-06-11',
    capacityDomestic: 20,
    capacityOverseas: 12,
    isClosed: false,
    isHidden: false,
  }
];

export const MOCK_TICKETS: Ticket[] = [
  {
    id: 't-1',
    title: 'Button Component V2',
    jiraLink: 'https://jira.example.com/browse/PAGES-101',
    points: 5,
    sprintId: 'sprint-1',
    status: TicketStatus.IN_PROGRESS,
    createdAt: new Date().toISOString(),
    region: Region.DOMESTIC,
    strategyPlan: 'Support New Brand Identity',
    pagesPlan: 'Refactor base button props',
    desiredReleaseDate: '2024-05-20',
    order: 100
  },
  {
    id: 't-2',
    title: 'Modal Accessibility Fixes',
    jiraLink: 'https://jira.example.com/browse/PAGES-102',
    points: 3,
    sprintId: 'sprint-1',
    status: TicketStatus.TODO,
    createdAt: new Date().toISOString(),
    region: Region.OVERSEAS,
    strategyPlan: 'Compliance requirement',
    desiredReleaseDate: '2024-05-10',
    order: 200
  },
  {
    id: 't-3',
    title: 'New DatePicker',
    jiraLink: 'https://jira.example.com/browse/PAGES-204',
    points: 8, 
    sprintId: 'sprint-2',
    status: TicketStatus.BACKLOG,
    createdAt: new Date().toISOString(),
    region: Region.DOMESTIC,
    order: 300
  },
  {
    id: 't-4',
    title: 'Typography Updates',
    jiraLink: 'https://jira.example.com/browse/PAGES-305',
    points: 2,
    sprintId: null,
    status: TicketStatus.BACKLOG,
    createdAt: new Date().toISOString(),
    region: Region.OVERSEAS,
    order: 400
  }
];