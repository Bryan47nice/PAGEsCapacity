import React, { useState, useEffect } from 'react';
import { Sprint, Ticket, UserRole, TicketStatus, Region } from './types';
import { MOCK_SPRINTS, MOCK_TICKETS } from './constants';
import { SprintColumn } from './components/SprintColumn';
import { NewRequestModal } from './components/NewRequestModal';
import { EditSprintModal } from './components/EditSprintModal';
import { Layers, Plus, Shield, Monitor, Globe, MapPin, LayoutGrid, Menu } from 'lucide-react';

function App() {
  // --- State Management ---
  const [sprints, setSprints] = useState<Sprint[]>(MOCK_SPRINTS);
  const [tickets, setTickets] = useState<Ticket[]>(MOCK_TICKETS);
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>(UserRole.STRATEGY); 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTicket, setEditingTicket] = useState<Ticket | null>(null);
  const [preSelectedSprintId, setPreSelectedSprintId] = useState<string | null>(null); // New: For Quick Add
  
  // Edit Sprint Modal State
  const [isSprintModalOpen, setIsSprintModalOpen] = useState(false);
  const [editingSprint, setEditingSprint] = useState<Sprint | null>(null);
  
  // Filters
  const [regionFilter, setRegionFilter] = useState<Region | 'ALL'>('ALL');

  // --- Persistence (Simulated) ---
  useEffect(() => {
    const savedSprints = localStorage.getItem('pages_sprints_v3');
    const savedTickets = localStorage.getItem('pages_tickets_v3');
    if (savedSprints) setSprints(JSON.parse(savedSprints));
    if (savedTickets) setTickets(JSON.parse(savedTickets));
  }, []);

  useEffect(() => {
    localStorage.setItem('pages_sprints_v3', JSON.stringify(sprints));
    localStorage.setItem('pages_tickets_v3', JSON.stringify(tickets));
  }, [sprints, tickets]);

  // --- Handlers ---

  // Create or Update Ticket
  const handleSaveTicket = (data: Partial<Ticket>) => {
    if (editingTicket) {
        // Update existing
        setTickets(prev => prev.map(t => 
            t.id === editingTicket.id ? { ...t, ...data } : t
        ));
        setEditingTicket(null);
    } else {
        // Create new
        // Find max order to append at end
        const maxOrder = tickets.reduce((max, t) => Math.max(max, t.order || 0), 0);

        const newTicket: Ticket = {
            id: `t-${Date.now()}`,
            title: data.title || '未命名需求',
            jiraLink: data.jiraLink || '',
            points: data.points || 1,
            sprintId: data.sprintId || null, // Use selected sprint ID
            status: TicketStatus.BACKLOG,
            createdAt: new Date().toISOString(),
            region: data.region || Region.DOMESTIC,
            strategyPlan: data.strategyPlan,
            pagesPlan: data.pagesPlan,
            desiredReleaseDate: data.desiredReleaseDate,
            order: maxOrder + 100,
            isHidden: false
        };
        setTickets([...tickets, newTicket]);
    }
    setPreSelectedSprintId(null);
  };

  const handleMoveTicket = (ticketId: string, sprintId: string | null) => {
    if (currentUserRole !== UserRole.PAGES) return;
    
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return { ...t, sprintId: sprintId };
      }
      return t;
    }));
  };

  // Changed from Deleting to Toggling Visibility (Hide/Restore)
  const handleToggleTicketVisibility = (ticketId: string) => {
     setTickets(prev => prev.map(t => 
        t.id === ticketId ? { ...t, isHidden: !t.isHidden } : t
     ));
     closeModal();
  };
  
  const handleEditTicketClick = (ticket: Ticket) => {
      setEditingTicket(ticket);
      setPreSelectedSprintId(null);
      setIsModalOpen(true);
  };

  // New: Handle Quick Add to Sprint
  const handleQuickAddTicket = (sprintId: string | null) => {
      setEditingTicket(null);
      setPreSelectedSprintId(sprintId);
      setIsModalOpen(true);
  };

  // Edit Sprint Handlers
  const handleEditSprintClick = (sprint: Sprint) => {
      if (currentUserRole !== UserRole.PAGES) return;
      setEditingSprint(sprint);
      setIsSprintModalOpen(true);
  };

  const handleSaveSprintChanges = (sprintId: string, data: Partial<Sprint>) => {
      setSprints(prev => prev.map(s => 
          s.id === sprintId ? { ...s, ...data } : s
      ));
      setIsSprintModalOpen(false);
  };

  const handleDeleteSprint = (sprintId: string) => {
      // Logic is now triggered from within the modal, but logic remains here
      const sprintToDelete = sprints.find(s => s.id === sprintId);
      const ticketCount = tickets.filter(t => t.sprintId === sprintId).length;
      
      if (window.confirm(`確定要刪除「${sprintToDelete?.name}」嗎？\n\n注意：目前此 Sprint 內有 ${ticketCount} 張單，刪除後將自動移回「待辦清單 (Backlog)」。`)) {
          // 1. Move tickets to backlog
          setTickets(prev => prev.map(t => t.sprintId === sprintId ? { ...t, sprintId: null } : t));
          // 2. Remove Sprint
          setSprints(prev => prev.filter(s => s.id !== sprintId));
      }
      setIsSprintModalOpen(false); // Close modal if it was called from there
  };

  const handleToggleSprintVisibility = (sprintId: string) => {
    if (currentUserRole !== UserRole.PAGES) return;
    setSprints(prev => prev.map(s => 
      s.id === sprintId ? { ...s, isHidden: !s.isHidden } : s
    ));
  };

  const handleAddSprint = () => {
     if (currentUserRole !== UserRole.PAGES) return;
     
     const lastSprint = sprints[sprints.length - 1];
     let newStartDate = new Date();
     let newEndDate = new Date();
     
     // Default to start tomorrow if no sprints, otherwise day after last sprint ends
     if (lastSprint) {
         const lastEnd = new Date(lastSprint.endDate);
         newStartDate = new Date(lastEnd);
         newStartDate.setDate(lastEnd.getDate() + 1);
     }
     
     // Default 2 weeks (13 days after start)
     newEndDate = new Date(newStartDate);
     newEndDate.setDate(newStartDate.getDate() + 13);
     
     const newSprintName = `Sprint ${newStartDate.getFullYear()}-${String(newStartDate.getMonth() + 1).padStart(2, '0')}`;

     const newSprint: Sprint = {
         id: `sprint-${Date.now()}`,
         name: newSprintName,
         startDate: newStartDate.toISOString().split('T')[0],
         endDate: newEndDate.toISOString().split('T')[0],
         capacityDomestic: lastSprint ? lastSprint.capacityDomestic : 20,
         capacityOverseas: lastSprint ? lastSprint.capacityOverseas : 10,
         isClosed: false,
         isHidden: false
     };
     
     setSprints([...sprints, newSprint]);
  };

  // Reordering Logic
  const handleTicketDrop = (movedTicketId: string, targetSprintId: string | null, targetTicketId?: string) => {
      // Allow drop if user is PAGES PM OR if filtered by region
      const canReorder = currentUserRole === UserRole.PAGES || regionFilter !== 'ALL';
      if (!canReorder) return;

      const movedTicket = tickets.find(t => t.id === movedTicketId);
      if (!movedTicket) return;

      // Create a copy
      let newTickets = [...tickets];
      
      // 1. Update Sprint ID first (Moving between lists)
      newTickets = newTickets.map(t => 
        t.id === movedTicketId ? { ...t, sprintId: targetSprintId } : t
      );

      // 2. Handle Reordering 
      if (targetTicketId && targetTicketId !== movedTicketId) {
          // Get all tickets in the target sprint filtered by current view context (or just sprint if ALL + Admin)
          const relevantTickets = newTickets
            .filter(t => {
                const matchesSprint = t.sprintId === targetSprintId;
                const matchesRegion = regionFilter === 'ALL' ? true : t.region === regionFilter;
                // Sort by order, but technically "hidden" items are rendered separately in the UI. 
                // For drag logic, we treat them all as a flat list here, but the UI will group them.
                return matchesSprint && matchesRegion;
            })
            .sort((a, b) => (a.order || 0) - (b.order || 0));
          
          const movedIndex = relevantTickets.findIndex(t => t.id === movedTicketId);
          const targetIndex = relevantTickets.findIndex(t => t.id === targetTicketId);
          
          if (movedIndex !== -1 && targetIndex !== -1) {
             // Remove moved ticket from array
             const [removed] = relevantTickets.splice(movedIndex, 1);
             // Insert at new position
             relevantTickets.splice(targetIndex, 0, removed);

             // Reassign order values based on new array index * 100
             relevantTickets.forEach((t, index) => {
                 t.order = (index + 1) * 100;
             });

             // Merge back into main list
             newTickets = newTickets.map(t => {
                 const updated = relevantTickets.find(rt => rt.id === t.id);
                 return updated ? updated : t;
             });
          }
      }

      setTickets(newTickets);
  };

  // --- Computed ---
  
  // 1. Filter by Region (Ticket List)
  const filteredTickets = tickets.filter(t => {
      if (regionFilter === 'ALL') return true;
      return t.region === regionFilter;
  });

  // 2. Sort Function
  const getSortedTickets = (rawTickets: Ticket[]) => {
      // Always sort by order for drag-and-drop consistency
      return [...rawTickets].sort((a, b) => (a.order || 0) - (b.order || 0));
  };

  const backlogTickets = getSortedTickets(filteredTickets.filter(t => t.sprintId === null));
  const sortedSprints = [...sprints].sort((a, b) => a.startDate.localeCompare(b.startDate));

  const closeModal = () => {
      setIsModalOpen(false);
      setEditingTicket(null);
      setPreSelectedSprintId(null);
  }

  return (
    <div className="h-screen flex flex-col text-slate-800 font-sans bg-slate-50 overflow-hidden">
      {/* Top Navigation */}
      <header className="bg-white border-b border-gray-200 z-20 shadow-sm shrink-0">
        <div className="max-w-[1800px] mx-auto px-4 md:px-6 py-3">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 md:gap-0">
                {/* Logo & Title */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <div className="bg-indigo-600 text-white p-1.5 md:p-2 rounded-lg shrink-0">
                            <Layers size={20} className="md:w-6 md:h-6" />
                        </div>
                        <div>
                            <h1 className="text-lg md:text-xl font-bold text-gray-900 tracking-tight leading-tight">PAGEs <span className="text-indigo-600 font-light hidden sm:inline">產能規劃工具</span></h1>
                            <p className="text-[10px] md:text-xs text-gray-500 font-medium leading-tight">元件庫產能管理</p>
                        </div>
                    </div>
                    {/* Mobile Add Button (Visible only on small screens) */}
                    <button 
                        onClick={() => { setEditingTicket(null); setPreSelectedSprintId(null); setIsModalOpen(true); }}
                        className="md:hidden bg-indigo-600 text-white p-2 rounded-lg shadow-sm"
                    >
                        <Plus size={20} />
                    </button>
                </div>

                {/* Controls Container */}
                <div className="flex flex-wrap items-center justify-between md:justify-end gap-3 md:gap-4 md:h-auto">
                    {/* Region Filter */}
                    <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200 shrink-0">
                        <button 
                            onClick={() => setRegionFilter('ALL')}
                            className={`p-1.5 rounded-md text-[10px] md:text-xs font-semibold flex items-center gap-1 transition-all ${regionFilter === 'ALL' ? 'bg-white shadow text-gray-800' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <LayoutGrid size={14} /> <span className="hidden sm:inline">全部</span>
                        </button>
                         <div className="w-px bg-gray-300 my-1 mx-0.5 md:mx-1"></div>
                        <button 
                            onClick={() => setRegionFilter(Region.DOMESTIC)}
                            className={`p-1.5 rounded-md text-[10px] md:text-xs font-semibold flex items-center gap-1 transition-all ${regionFilter === Region.DOMESTIC ? 'bg-white shadow text-indigo-700' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <MapPin size={14} /> 國內
                        </button>
                        <button 
                            onClick={() => setRegionFilter(Region.OVERSEAS)}
                            className={`p-1.5 rounded-md text-[10px] md:text-xs font-semibold flex items-center gap-1 transition-all ${regionFilter === Region.OVERSEAS ? 'bg-white shadow text-blue-700' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <Globe size={14} /> 海外
                        </button>
                    </div>

                    <div className="hidden md:block h-6 w-px bg-gray-200"></div>

                    {/* Role Switcher */}
                    <div className="flex items-center bg-gray-100 rounded-full p-1 border border-gray-200 shrink-0">
                        <button 
                            onClick={() => setCurrentUserRole(UserRole.STRATEGY)}
                            className={`px-3 md:px-4 py-1 md:py-1.5 rounded-full text-[10px] md:text-sm font-medium transition-all flex items-center ${currentUserRole === UserRole.STRATEGY ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            {currentUserRole === UserRole.STRATEGY ? <Monitor size={12} className="mr-1 md:w-[14px] md:h-[14px]"/> : null}
                            <span className="hidden sm:inline">策略 PM</span> <span className="sm:hidden">策略</span>
                        </button>
                        <button 
                            onClick={() => setCurrentUserRole(UserRole.PAGES)}
                            className={`px-3 md:px-4 py-1 md:py-1.5 rounded-full text-[10px] md:text-sm font-medium transition-all flex items-center ${currentUserRole === UserRole.PAGES ? 'bg-indigo-600 shadow-sm text-white' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            {currentUserRole === UserRole.PAGES ? <Shield size={12} className="mr-1 md:w-[14px] md:h-[14px]"/> : null}
                            <span className="hidden sm:inline">PAGEs PM</span> <span className="sm:hidden">PAGEs</span>
                        </button>
                    </div>

                    {/* Desktop Add Button */}
                    <button 
                        onClick={() => { setEditingTicket(null); setPreSelectedSprintId(null); setIsModalOpen(true); }}
                        className="hidden md:flex bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-semibold shadow-md shadow-indigo-200 items-center transition-transform transform active:scale-95 text-sm"
                    >
                        <Plus size={16} className="mr-1.5" />
                        新增需求
                    </button>
                </div>
            </div>
        </div>
      </header>

      {/* Role Banner */}
      <div className={`w-full py-1.5 text-center text-[10px] md:text-xs font-bold shrink-0 ${currentUserRole === UserRole.PAGES ? 'bg-indigo-50 text-indigo-800' : 'bg-gray-100 text-gray-600'}`}>
         目前檢視身分：{currentUserRole === UserRole.PAGES ? "PAGEs Team (管理員/產能控管)" : "策略 PM (需求方/檢視者)"}
      </div>

      {/* Main Board Area */}
      <main className="flex-1 overflow-x-auto overflow-y-hidden bg-slate-50 scroll-smooth snap-x snap-mandatory md:snap-none">
        <div className="h-full p-4 md:p-6 flex space-x-4 md:space-x-6 w-max">
            {/* Backlog Column */}
            <SprintColumn 
                sprint={null}
                tickets={backlogTickets}
                role={currentUserRole}
                allSprints={sprints}
                onMoveSprint={handleMoveTicket}
                onEditSprint={handleEditSprintClick}
                onToggleVisibility={handleToggleSprintVisibility}
                onEditTicket={handleEditTicketClick}
                isReorderingEnabled={regionFilter !== 'ALL' || currentUserRole === UserRole.PAGES}
                onTicketDrop={handleTicketDrop}
                onQuickAdd={() => handleQuickAddTicket(null)}
            />

            {/* Divider (Hidden on Mobile to let snap work better) */}
            <div className="hidden md:block w-px bg-gray-300 my-4"></div>

            {/* Sprints */}
            {sortedSprints.map(sprint => (
                <SprintColumn 
                    key={sprint.id}
                    sprint={sprint}
                    tickets={getSortedTickets(filteredTickets.filter(t => t.sprintId === sprint.id))}
                    role={currentUserRole}
                    allSprints={sprints}
                    onMoveSprint={handleMoveTicket}
                    onEditSprint={handleEditSprintClick}
                    onToggleVisibility={handleToggleSprintVisibility}
                    onEditTicket={handleEditTicketClick}
                    isReorderingEnabled={regionFilter !== 'ALL' || currentUserRole === UserRole.PAGES}
                    onTicketDrop={handleTicketDrop}
                    onQuickAdd={() => handleQuickAddTicket(sprint.id)}
                />
            ))}

            {/* Empty State Helper for Admin */}
            {currentUserRole === UserRole.PAGES && (
                <div 
                    onClick={handleAddSprint}
                    className="w-[85vw] md:w-[320px] md:min-w-[320px] h-full flex items-center justify-center border-2 border-dashed border-gray-300 rounded-xl bg-gray-50/50 hover:bg-gray-100 cursor-pointer transition-colors group opacity-60 snap-center shrink-0"
                >
                    <div className="text-center text-gray-400 group-hover:text-gray-600">
                        <Plus size={48} className="mx-auto mb-2" />
                        <p className="font-medium">新增下一個 Sprint</p>
                    </div>
                </div>
            )}
            
            {/* Padding for mobile scrolling end */}
            <div className="w-4 md:w-0 shrink-0"></div>
        </div>
      </main>

      {/* Modals */}
      <NewRequestModal 
        isOpen={isModalOpen} 
        onClose={closeModal} 
        onSubmit={handleSaveTicket}
        onDelete={handleToggleTicketVisibility}
        role={currentUserRole}
        editingTicket={editingTicket}
        sprints={sprints}
        initialSprintId={preSelectedSprintId}
      />

      <EditSprintModal 
        isOpen={isSprintModalOpen}
        onClose={() => setIsSprintModalOpen(false)}
        sprint={editingSprint}
        onSave={handleSaveSprintChanges}
      />
    </div>
  );
}

export default App;