import React, { useState, useEffect } from 'react';
import { Sprint } from '../types';
import { X, Calendar, Save, Layers, BarChart2 } from 'lucide-react';

interface EditSprintModalProps {
  isOpen: boolean;
  onClose: () => void;
  sprint: Sprint | null;
  onSave: (sprintId: string, data: Partial<Sprint>) => void;
}

export const EditSprintModal: React.FC<EditSprintModalProps> = ({ 
  isOpen, 
  onClose, 
  sprint, 
  onSave
}) => {
  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [capacityDomestic, setCapacityDomestic] = useState(0);
  const [capacityOverseas, setCapacityOverseas] = useState(0);

  useEffect(() => {
    if (sprint) {
      setName(sprint.name);
      setStartDate(sprint.startDate);
      setEndDate(sprint.endDate);
      setCapacityDomestic(sprint.capacityDomestic);
      setCapacityOverseas(sprint.capacityOverseas);
    }
  }, [sprint, isOpen]);

  if (!isOpen || !sprint) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(sprint.id, {
      name,
      startDate,
      endDate,
      capacityDomestic,
      capacityOverseas
    });
    onClose();
  };

  // Common input style for better visibility
  const inputClass = "w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm text-gray-900 placeholder-gray-400";

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50 backdrop-blur-sm p-0 md:p-4">
      <div className="bg-white rounded-t-xl md:rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-indigo-600 text-white">
          <div className="flex items-center gap-2">
            <Layers size={20} />
            <h2 className="font-bold text-lg">編輯 Sprint 資訊</h2>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto">
            
            {/* Basic Info Section */}
            <div className="space-y-4">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                    <Calendar size={12} /> 基本資訊
                </h3>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Sprint 名稱</label>
                    <input 
                        type="text" 
                        required
                        className={inputClass}
                        value={name}
                        onChange={e => setName(e.target.value)}
                    />
                </div>
                <div className="flex gap-4">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">開始日期</label>
                        <input 
                            type="date" 
                            required
                            className={inputClass}
                            value={startDate}
                            onChange={e => setStartDate(e.target.value)}
                        />
                    </div>
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">結束日期</label>
                        <input 
                            type="date" 
                            required
                            className={inputClass}
                            value={endDate}
                            onChange={e => setEndDate(e.target.value)}
                        />
                    </div>
                </div>
            </div>

            <hr className="border-gray-100"/>

            {/* Capacity Section */}
            <div className="space-y-4">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                    <BarChart2 size={12} /> 產能設定 (Capacity Points)
                </h3>
                <div className="flex gap-4">
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">國內產能</label>
                        <div className="flex items-center">
                            <input 
                                type="number" 
                                min="0"
                                className={inputClass}
                                value={capacityDomestic}
                                onChange={e => setCapacityDomestic(Number(e.target.value))}
                            />
                            <span className="ml-2 text-sm text-gray-500">pts</span>
                        </div>
                    </div>
                    <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">海外產能</label>
                        <div className="flex items-center">
                             <input 
                                type="number" 
                                min="0"
                                className={inputClass}
                                value={capacityOverseas}
                                onChange={e => setCapacityOverseas(Number(e.target.value))}
                            />
                            <span className="ml-2 text-sm text-gray-500">pts</span>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        {/* Footer Actions */}
        <div className="p-4 border-t border-gray-100 bg-gray-50 flex justify-end items-center">
            <div className="flex gap-3">
                <button 
                    onClick={onClose}
                    className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium transition-colors"
                >
                    取消
                </button>
                <button 
                    onClick={handleSubmit}
                    className="px-6 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 flex items-center transition-colors"
                >
                    <Save size={16} className="mr-1.5"/> 儲存設定
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};