import React, { useState } from 'react';
import { Sprint, Ticket, UserRole, Region } from '../types';
import { TicketCard } from './TicketCard';
import { Calendar, Edit3, EyeOff, Plus, Maximize2, ChevronDown, ChevronRight } from 'lucide-react';

interface SprintColumnProps {
  sprint: Sprint | null; // null represents Backlog
  tickets: Ticket[];
  role: UserRole;
  allSprints: Sprint[];
  onMoveSprint: (ticketId: string, sprintId: string | null) => void;
  onEditSprint?: (sprint: Sprint) => void;
  onToggleVisibility?: (sprintId: string) => void;
  onEditTicket: (ticket: Ticket) => void;
  isReorderingEnabled: boolean;
  onTicketDrop: (ticketId: string, targetSprintId: string | null, targetTicketId?: string) => void;
  onQuickAdd: () => void;
}

export const SprintColumn: React.FC<SprintColumnProps> = ({ 
  sprint, 
  tickets, 
  role, 
  allSprints, 
  onMoveSprint,
  onEditSprint,
  onToggleVisibility,
  onEditTicket,
  isReorderingEnabled,
  onTicketDrop,
  onQuickAdd
}) => {
  const isBacklog = !sprint;

  // Hidden Tickets Toggle State - Defaults to false (collapsed)
  const [showHidden, setShowHidden] = useState(false);

  // Separate Tickets into Visible and Hidden
  const visibleTickets = tickets.filter(t => !t.isHidden);
  const hiddenTickets = tickets.filter(t => t.isHidden);

  // Calculate Points (Based on active/visible tickets)
  const activeDomesticTickets = visibleTickets.filter(t => t.region === Region.DOMESTIC);
  const activeOverseasTickets = visibleTickets.filter(t => t.region === Region.OVERSEAS);
  const domesticPoints = activeDomesticTickets.reduce((acc, t) => acc + t.points, 0);
  const overseasPoints = activeOverseasTickets.reduce((acc, t) => acc + t.points, 0);

  // Handle Hidden Column State
  if (sprint && sprint.isHidden) {
      return (
          <div className="h-full w-14 bg-gray-100 rounded-xl border border-gray-200 flex flex-col items-center py-4 gap-4 hover:bg-gray-200 transition-colors group snap-center shrink-0">
              <button 
                onClick={() => onToggleVisibility && onToggleVisibility(sprint.id)}
                className="p-2 bg-indigo-100 text-indigo-600 rounded-full hover:bg-indigo-200 shadow-sm"
                title="展開 Sprint"
              >
                  <Maximize2 size={18} />
              </button>
              
              <div className="flex-1 flex flex-col items-center justify-center overflow-hidden">
                  {/* Using inline writing-mode style to ensure compatibility */}
                  <div style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }} className="rotate-180 text-gray-500 font-bold tracking-widest whitespace-nowrap py-4 text-sm truncate">
                      {sprint.name}
                  </div>
              </div>
              
              <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-xs font-bold text-gray-600 mb-2">
                  {visibleTickets.length}
              </div>
          </div>
      );
  }

  const CapacityBar = ({ label, current, max, colorClass }: { label: string, current: number, max: number, colorClass: string }) => {
    const percentage = max > 0 ? Math.min((current / max) * 100, 100) : 0;
    const isOver = current > max;

    return (
        <div className="mb-2">
            <div className="flex justify-between text-[10px] mb-0.5 uppercase font-semibold tracking-wider text-gray-500">
                <span>{label}</span>
                <span className={isOver ? 'text-red-600' : ''}>{current} / {max}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div 
                    className={`h-1.5 rounded-full transition-all duration-500 ${isOver ? 'bg-red-500' : colorClass}`} 
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    );
  };

  // DnD Handlers
  const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault(); 
  };

  const handleDrop = (e: React.DragEvent, targetTicketId?: string) => {
      e.preventDefault();
      if (!isReorderingEnabled && !isBacklog) {
          return;
      }
      
      const ticketId = e.dataTransfer.getData('ticketId'); 
      if (ticketId) {
        onTicketDrop(ticketId, sprint ? sprint.id : null, targetTicketId);
      }
  };

  return (
    <div 
        className="flex flex-col h-full w-[85vw] min-w-[300px] md:w-[360px] md:min-w-[320px] md:max-w-[360px] shrink-0 bg-gray-50 rounded-xl border border-gray-200 overflow-hidden snap-center"
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e)}
    >
      {/* Header */}
      <div className={`p-4 border-b border-gray-200 ${isBacklog ? 'bg-gray-100' : 'bg-white'}`}>
        
        <div className="flex justify-between items-start mb-2">
            <div className="flex-1 mr-2 overflow-hidden">
                <div className="flex items-center justify-between">
                    <h3 className="font-bold text-gray-800 text-lg truncate leading-tight">
                        {isBacklog ? '待辦清單' : sprint?.name}
                    </h3>
                    
                    {!isBacklog && sprint && role === UserRole.PAGES && (
                        <div className="flex items-center shrink-0">
                            {/* Replaced Delete button with Edit button */}
                            <button 
                                onClick={() => onEditSprint && onEditSprint(sprint)}
                                className="ml-2 text-gray-400 hover:text-indigo-500 hover:bg-indigo-50 p-1 rounded transition-colors"
                                title="編輯 Sprint 資訊與產能"
                            >
                                <Edit3 size={14} />
                            </button>

                            <button 
                                onClick={() => onToggleVisibility && onToggleVisibility(sprint.id)}
                                className="ml-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 p-1 rounded transition-colors"
                                title="隱藏 (收合) Sprint"
                            >
                                <EyeOff size={14} />
                            </button>
                        </div>
                    )}
                </div>

                    {!isBacklog && sprint && (
                    <div className="flex items-center text-xs text-gray-500 mt-1 group">
                        <Calendar size={12} className="mr-1 shrink-0" />
                        <span className="truncate">{new Date(sprint.startDate).toLocaleDateString()} - {new Date(sprint.endDate).toLocaleDateString()}</span>
                    </div>
                )}
            </div>

            <div className="flex flex-col items-end gap-1">
                <span className="bg-gray-200 text-gray-600 text-xs px-2 py-1 rounded-full font-medium shrink-0">
                    {visibleTickets.length}
                </span>
            </div>
        </div>

        {!isBacklog && sprint && (
            <div className="mt-3">
                <div className="bg-gray-50 p-2 rounded border border-gray-100 relative">
                    <CapacityBar 
                        label="國內產能" 
                        current={domesticPoints} 
                        max={sprint.capacityDomestic} 
                        colorClass="bg-indigo-500"
                    />
                    <CapacityBar 
                        label="海外產能" 
                        current={overseasPoints} 
                        max={sprint.capacityOverseas} 
                        colorClass="bg-blue-500"
                    />
                </div>
            </div>
        )}
        {isBacklog && (
            <div className="text-xs text-gray-500 mt-2">
                尚未分配的需求
            </div>
        )}
      </div>

      {/* Ticket List */}
      <div className="flex-1 overflow-y-auto p-2 md:p-3 space-y-3 min-h-[150px] flex flex-col">
        {visibleTickets.length === 0 && hiddenTickets.length === 0 ? (
            <div className="h-24 flex items-center justify-center text-gray-400 text-sm border-2 border-dashed border-gray-200 rounded-lg">
                No tickets
            </div>
        ) : (
            <>
                {/* Active Tickets */}
                {visibleTickets.map(ticket => (
                    <div 
                        key={ticket.id}
                        onDragOver={handleDragOver}
                        onDrop={(e) => {
                            e.stopPropagation();
                            handleDrop(e, ticket.id);
                        }}
                    >
                        <TicketCard 
                            ticket={ticket} 
                            role={role}
                            allSprints={allSprints}
                            onMoveSprint={onMoveSprint}
                            onEdit={onEditTicket}
                            isDraggable={isReorderingEnabled}
                            onDragStart={(e, id) => e.dataTransfer.setData('ticketId', id)}
                        />
                    </div>
                ))}

                {/* Spacer to push hidden tickets to bottom if list is short */}
                <div className="flex-1"></div>

                {/* Hidden Tickets Section */}
                {hiddenTickets.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-gray-200">
                        <button 
                            onClick={() => setShowHidden(!showHidden)}
                            className="flex items-center justify-between w-full text-xs text-gray-500 hover:text-gray-700 hover:bg-gray-100 px-2 py-1.5 rounded transition-colors mb-1"
                        >
                            <span className="flex items-center font-medium">
                                {showHidden ? <ChevronDown size={14} className="mr-1.5"/> : <ChevronRight size={14} className="mr-1.5"/>}
                                已隱藏項目
                            </span>
                            <span className="bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded-full text-[10px] font-bold">
                                {hiddenTickets.length}
                            </span>
                        </button>

                        {showHidden && (
                            <div className="space-y-2 p-2 bg-gray-100/50 rounded-lg border border-gray-200/50 animate-in fade-in slide-in-from-top-2 duration-200">
                                {hiddenTickets.map(ticket => (
                                    <div key={ticket.id} className="opacity-75 hover:opacity-100 transition-opacity">
                                        <TicketCard 
                                            ticket={ticket} 
                                            role={role}
                                            allSprints={allSprints}
                                            onMoveSprint={onMoveSprint}
                                            onEdit={onEditTicket}
                                            isDraggable={false} // Disable drag for hidden items
                                        />
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </>
        )}
      </div>
      
      {/* Quick Add Button at Bottom */}
      <div className="p-2 md:p-3 border-t border-gray-200 bg-gray-50 hover:bg-gray-100 transition-colors shrink-0">
          <button 
            onClick={onQuickAdd}
            className="w-full flex items-center justify-center gap-2 py-2 text-sm text-gray-500 hover:text-indigo-600 border border-dashed border-gray-300 hover:border-indigo-300 rounded-lg transition-all"
          >
              <Plus size={16} />
              <span>新增需求</span>
          </button>
      </div>
    </div>
  );
};