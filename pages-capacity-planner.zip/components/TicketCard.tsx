import React from 'react';
import { Ticket, UserRole, Sprint, Region } from '../types';
import { ExternalLink, Calendar, MapPin, Globe, AlertTriangle, ArrowRight, EyeOff } from 'lucide-react';

interface TicketCardProps {
  ticket: Ticket;
  role: UserRole;
  allSprints: Sprint[];
  onMoveSprint: (ticketId: string, sprintId: string | null) => void;
  onEdit: (ticket: Ticket) => void;
  isDraggable: boolean;
  onDragStart?: (e: React.DragEvent, ticketId: string) => void;
}

export const TicketCard: React.FC<TicketCardProps> = ({ 
  ticket, 
  role, 
  allSprints, 
  onMoveSprint, 
  onEdit,
  isDraggable,
  onDragStart
}) => {

  const getPointsColor = (p: number) => {
    if (ticket.isHidden) return 'bg-gray-100 text-gray-500'; // Grayscale for hidden
    if (p < 1) return 'bg-blue-50 text-blue-600'; // Style for 0.5
    if (p <= 3) return 'bg-green-100 text-green-800';
    if (p <= 5) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  // --- Date Calculation Logic ---
  let calculatedReleaseDateStr = '';
  let calculatedReleaseDateObj: Date | null = null;

  const currentSprintIndex = allSprints.findIndex(s => s.id === ticket.sprintId);
  const currentSprint = allSprints[currentSprintIndex];

  if (currentSprint) {
      // Rule: Sprint End Date + 7 Days
      const endDate = new Date(currentSprint.endDate);
      const targetDate = new Date(endDate);
      targetDate.setDate(endDate.getDate() + 7);

      calculatedReleaseDateObj = targetDate;
      calculatedReleaseDateStr = targetDate.toISOString().split('T')[0];
  } else if (ticket.sprintId) {
     calculatedReleaseDateStr = 'TBD';
  }

  // Validation: Desired Date vs Calculated Date
  const isRisk = ticket.desiredReleaseDate && calculatedReleaseDateObj && new Date(ticket.desiredReleaseDate) < calculatedReleaseDateObj;

  const handleDragStart = (e: React.DragEvent) => {
      if (onDragStart) onDragStart(e, ticket.id);
  };

  return (
    <div 
        draggable={isDraggable}
        onDragStart={handleDragStart}
        onClick={() => onEdit(ticket)}
        className={`
            bg-white p-3 md:p-3 rounded-lg border shadow-sm transition-all relative group cursor-pointer select-none
            ${isDraggable ? 'cursor-grab active:cursor-grabbing' : ''}
            ${ticket.isHidden ? 'border-gray-100 grayscale bg-gray-50' : 'border-gray-200 hover:shadow-md hover:border-indigo-300 active:bg-gray-50'}
        `}
    >
      {/* Header: Title & Controls */}
      <div className="flex justify-between items-start mb-2 gap-2">
        <div className="flex-1">
             <div className="flex items-center gap-1 mb-1.5">
                {ticket.region === Region.DOMESTIC ? (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded flex items-center border ${ticket.isHidden ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-yellow-50 text-yellow-700 border-yellow-100'}`}>
                        <MapPin size={8} className="mr-0.5"/> 國內
                    </span>
                ) : (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded flex items-center border ${ticket.isHidden ? 'bg-gray-100 text-gray-500 border-gray-200' : 'bg-purple-50 text-purple-700 border-purple-100'}`}>
                        <Globe size={8} className="mr-0.5"/> 海外
                    </span>
                )}
                {ticket.isHidden && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded flex items-center bg-gray-200 text-gray-600">
                        <EyeOff size={8} className="mr-0.5" /> 隱藏
                    </span>
                )}
             </div>
            <h4 className={`font-semibold leading-snug text-sm ${ticket.isHidden ? 'text-gray-500 line-through' : 'text-gray-900'}`}>{ticket.title}</h4>
        </div>
        
        <div className="flex items-center shrink-0 gap-1" onClick={e => e.stopPropagation()}>
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${getPointsColor(ticket.points)}`}>
                {ticket.points}
            </span>
        </div>
      </div>
      
      {/* JIRA Link */}
      <div className="mb-3" onClick={e => e.stopPropagation()}>
          {ticket.jiraLink && (
            <a 
                href={ticket.jiraLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className={`text-xs hover:underline flex items-center truncate py-1 ${ticket.isHidden ? 'text-gray-400 pointer-events-none' : 'text-indigo-600 hover:text-indigo-800'}`}
                title={ticket.jiraLink}
            >
                <ExternalLink size={10} className="mr-1 shrink-0" />
                <span className="truncate">{ticket.jiraLink.replace(/^https?:\/\//, '')}</span>
            </a>
          )}
      </div>
      
      {/* Release Calculation */}
      {ticket.sprintId && !ticket.isHidden && (
          <div className="bg-gray-50 rounded p-2 border border-gray-100 mb-1">
              {/* Calculated Release */}
              <div className="flex items-center text-[10px] text-gray-500 mb-1">
                  <ArrowRight size={10} className="mr-1 shrink-0"/> 
                  預期上線: <span className="font-medium ml-1">{calculatedReleaseDateStr}</span>
              </div>

              {/* User Desired Date */}
              {ticket.desiredReleaseDate && (
                  <div className={`flex items-center text-[10px] ${isRisk ? 'text-red-600 font-bold' : 'text-gray-500'}`}>
                      {isRisk ? <AlertTriangle size={10} className="mr-1 shrink-0" /> : <Calendar size={10} className="mr-1 shrink-0"/>}
                      期望上線: {ticket.desiredReleaseDate}
                  </div>
              )}
          </div>
      )}
    </div>
  );
};