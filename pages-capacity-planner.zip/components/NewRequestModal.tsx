import React, { useState, useEffect } from 'react';
import { UserRole, Region, Ticket, Sprint } from '../types';
import { estimatePoints } from '../services/geminiService';
import { X, Sparkles, Loader2, Globe, MapPin, ExternalLink, AlertTriangle, Calendar, Layers, EyeOff, Eye } from 'lucide-react';

interface NewRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Partial<Ticket>) => void;
  onDelete?: (ticketId: string) => void;
  role: UserRole;
  editingTicket?: Ticket | null;
  sprints: Sprint[];
  initialSprintId?: string | null;
}

export const NewRequestModal: React.FC<NewRequestModalProps> = ({ isOpen, onClose, onSubmit, onDelete, role, editingTicket, sprints, initialSprintId }) => {
  const [title, setTitle] = useState('');
  const [jiraLink, setJiraLink] = useState('');
  const [points, setPoints] = useState<number>(1);
  const [region, setRegion] = useState<Region>(Region.DOMESTIC);
  const [sprintId, setSprintId] = useState<string | null>(null);
  
  // New Fields
  const [desiredReleaseDate, setDesiredReleaseDate] = useState('');
  const [strategyPlan, setStrategyPlan] = useState('');
  const [pagesPlan, setPagesPlan] = useState('');

  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<string | null>(null);

  useEffect(() => {
    if (editingTicket) {
      setTitle(editingTicket.title);
      setJiraLink(editingTicket.jiraLink);
      setPoints(editingTicket.points);
      setRegion(editingTicket.region);
      setSprintId(editingTicket.sprintId);
      setDesiredReleaseDate(editingTicket.desiredReleaseDate || '');
      setStrategyPlan(editingTicket.strategyPlan || '');
      setPagesPlan(editingTicket.pagesPlan || '');
    } else {
      // Reset defaults
      setTitle('');
      setJiraLink('');
      setPoints(1);
      setRegion(Region.DOMESTIC);
      // If Quick Add passed an initial ID, use it, otherwise default to Backlog (null)
      setSprintId(initialSprintId || null);
      setDesiredReleaseDate('');
      setStrategyPlan('');
      setPagesPlan('');
      setAiSuggestion(null);
    }
  }, [editingTicket, isOpen, initialSprintId]);

  if (!isOpen) return null;

  const handleAiAssist = async () => {
    setIsAiLoading(true);
    setAiSuggestion(null);
    
    try {
      const estimation = await estimatePoints(title, "Jira Link: " + jiraLink);
      let estimatedPoints = estimation.points;
      if (estimatedPoints > 5) estimatedPoints = 5;
      
      setPoints(estimatedPoints);
      setAiSuggestion(estimation.reasoning);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ 
      title, 
      jiraLink, 
      points, 
      region,
      sprintId, 
      desiredReleaseDate,
      strategyPlan,
      pagesPlan
    });
    onClose();
  };

  const handleHideClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // e.stopPropagation() is removed to ensure button clicks bubble if needed, 
    // but prevented default so form doesn't submit.
    
    if (editingTicket && onDelete) {
        const isHidden = !!editingTicket.isHidden;
        const confirmText = isHidden 
            ? '確定要還原此需求單嗎？它將重新出現在列表中。'
            : '確定要隱藏此需求單嗎？它將被移至該列表底部的「已隱藏」區塊中，且不計入當前看板顯示。';

        if (window.confirm(confirmText)) {
            onDelete(editingTicket.id);
        }
    }
  };

  const renderLinkButton = (text: string) => {
      const isUrl = text.startsWith('http://') || text.startsWith('https://');
      if (isUrl) {
          return (
              <a href={text} target="_blank" rel="noreferrer" className="absolute right-2 top-2 p-1.5 bg-gray-100 hover:bg-indigo-100 text-indigo-600 rounded transition-colors">
                  <ExternalLink size={14} />
              </a>
          )
      }
      return null;
  }

  const inputClass = "w-full px-3 py-2 bg-white text-gray-900 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm md:text-base";

  // --- Expected Date Calculation Logic ---
  let calculatedReleaseDateStr = null;
  let calculatedReleaseDateObj: Date | null = null;
  let assignedSprintName = '';

  if (sprintId) {
      const sprintIndex = sprints.findIndex(s => s.id === sprintId);
      const sprint = sprints[sprintIndex];
      
      if (sprint) {
          assignedSprintName = sprint.name;
          const endDate = new Date(sprint.endDate);
          const targetDate = new Date(endDate);
          targetDate.setDate(endDate.getDate() + 7);
          
          calculatedReleaseDateObj = targetDate;
          calculatedReleaseDateStr = targetDate.toISOString().split('T')[0];
      }
  }

  const isDateRisk = desiredReleaseDate && calculatedReleaseDateObj && new Date(desiredReleaseDate) < calculatedReleaseDateObj;

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50 backdrop-blur-sm p-0 md:p-4">
      <div className="bg-white rounded-t-xl md:rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col h-[95vh] md:h-auto md:max-h-[90vh]">
        {/* Header */}
        <div className={`px-4 md:px-6 py-3 md:py-4 border-b border-gray-100 flex justify-between items-center shrink-0 ${editingTicket?.isHidden ? 'bg-gray-100' : 'bg-indigo-600'}`}>
          <div className="flex items-center gap-2">
            <h2 className={`font-bold text-base md:text-lg ${editingTicket?.isHidden ? 'text-gray-500' : 'text-white'}`}>
                {editingTicket ? '編輯需求與規劃' : '新增功能需求'}
            </h2>
            {editingTicket?.isHidden && (
                <span className="px-2 py-0.5 bg-gray-200 text-gray-600 text-xs rounded-full flex items-center border border-gray-300">
                    <EyeOff size={10} className="mr-1"/> 已隱藏
                </span>
            )}
          </div>
          <button onClick={onClose} className={`${editingTicket?.isHidden ? 'text-gray-400 hover:text-gray-600' : 'text-white/80 hover:text-white'} transition-colors`}>
            <X size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4 md:p-6 overflow-y-auto flex-1 space-y-4 md:space-y-5">
            
            {/* Top Row: Title & Region */}
            <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">需求標題 (Feature Title)</label>
                    <input 
                        type="text" 
                        required
                        className={inputClass}
                        placeholder="例如：新增深色模式開關"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                    />
                </div>
                <div className="w-full md:w-1/3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">區域 / 單位 (Region)</label>
                    <div className="flex rounded-lg border border-gray-300 overflow-hidden bg-white h-[42px]">
                        <button
                            type="button"
                            onClick={() => setRegion(Region.DOMESTIC)}
                            className={`flex-1 py-2 text-sm font-medium flex items-center justify-center gap-1 ${region === Region.DOMESTIC ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                        >
                           <MapPin size={14} /> 國內
                        </button>
                        <div className="w-px bg-gray-300"></div>
                        <button
                            type="button"
                            onClick={() => setRegion(Region.OVERSEAS)}
                            className={`flex-1 py-2 text-sm font-medium flex items-center justify-center gap-1 ${region === Region.OVERSEAS ? 'bg-blue-100 text-blue-700' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
                        >
                           <Globe size={14} /> 海外
                        </button>
                    </div>
                </div>
            </div>

            {/* Jira Link */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Jira / 規格連結 (Spec Link)</label>
                <div className="relative">
                    <input 
                        type="text" 
                        required
                        className={`${inputClass} pr-10`}
                        placeholder="https://jira.company.com/browse/..."
                        value={jiraLink}
                        onChange={e => setJiraLink(e.target.value)}
                    />
                     <button
                        type="button"
                        onClick={handleAiAssist}
                        disabled={isAiLoading || !title}
                        className="absolute top-1/2 -translate-y-1/2 right-2 text-indigo-600 hover:bg-indigo-50 p-1.5 rounded transition-colors"
                        title="AI 估算點數"
                    >
                        {isAiLoading ? <Loader2 size={18} className="animate-spin"/> : <Sparkles size={18}/>}
                    </button>
                </div>
                {aiSuggestion && (
                    <div className="mt-2 p-2 bg-indigo-50 border border-indigo-100 rounded text-xs text-indigo-800">
                        AI 建議: {aiSuggestion}
                    </div>
                )}
            </div>

            {/* Points & Sprint Selection Row */}
            <div className="flex flex-col md:flex-row gap-4">
                {/* Estimation */}
                <div className="w-full md:w-1/3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">點數 (Points)</label>
                    <select 
                        value={points} 
                        onChange={e => setPoints(Number(e.target.value))}
                        className={inputClass}
                    >
                        <option value={0.5}>0.5 - 極小</option>
                        <option value={1}>1 - 很小</option>
                        <option value={2}>2 - 簡單</option>
                        <option value={3}>3 - 小型</option>
                        <option value={5}>5 - 中型</option>
                    </select>
                </div>

                {/* Sprint Selector */}
                <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-1">分配至 Sprint</label>
                    <div className="relative">
                        <Layers size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
                        <select
                            value={sprintId || ''}
                            onChange={e => setSprintId(e.target.value || null)}
                            className={`${inputClass} pl-10`}
                        >
                            <option value="">待辦清單 (Backlog)</option>
                            {sprints.map(s => (
                                <option key={s.id} value={s.id}>
                                    {s.name} ({new Date(s.startDate).toLocaleDateString()} - {new Date(s.endDate).toLocaleDateString()})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            <hr className="border-gray-200" />

            {/* Expected Release Info (Read Only) */}
            <div className="bg-gray-50 rounded-lg border border-gray-200 p-3">
                <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-2 md:gap-0">
                    <div>
                        <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                           預估時程 (Predicted Timeline)
                        </h4>
                        <p className="text-sm text-gray-700">
                            {calculatedReleaseDateStr 
                                ? <span className="flex items-center font-medium"><Calendar size={14} className="mr-1"/> 預期可上線日: {calculatedReleaseDateStr}</span> 
                                : <span className="text-gray-500 italic">尚未分配 Sprint</span>
                            }
                        </p>
                        {assignedSprintName && <p className="text-xs text-gray-400 mt-0.5">基於分配的 Sprint：{assignedSprintName}</p>}
                    </div>
                    {isDateRisk && (
                        <div className="flex items-start bg-red-50 text-red-700 px-3 py-2 rounded text-xs md:max-w-[250px]">
                            <AlertTriangle size={16} className="shrink-0 mr-2 mt-0.5" />
                            <div>
                                <strong>警告：時程風險</strong>
                                <p>您的期望上線日 ({desiredReleaseDate}) 早於預期可上線日 ({calculatedReleaseDateStr})。</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">策略規劃 (Strategic Planning)</h3>

            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                         期望上線日 (Desired Release)
                    </label>
                    <div className="relative">
                         <Calendar size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
                        <input 
                            type="date" 
                            className={`${inputClass} pl-10 cursor-pointer ${isDateRisk ? 'border-red-300 bg-red-50 text-red-900' : ''}`}
                            value={desiredReleaseDate}
                            onChange={e => setDesiredReleaseDate(e.target.value)}
                        />
                    </div>
                    {isDateRisk && <p className="text-xs text-red-500 mt-1">日期不切實際，建議調整。</p>}
                </div>

                <div className="space-y-4">
                    <div className="relative">
                        <label className="block text-sm font-medium text-gray-700 mb-1">策略 PM 規劃</label>
                        <textarea
                            rows={3}
                            className={inputClass}
                            placeholder="策略備註或相關連結..."
                            value={strategyPlan}
                            onChange={e => setStrategyPlan(e.target.value)}
                        />
                        {renderLinkButton(strategyPlan)}
                    </div>
                    <div className="relative">
                        <label className="block text-sm font-medium text-gray-700 mb-1">PAGEs 規劃</label>
                        <textarea
                            rows={3}
                            className={inputClass}
                            placeholder="元件實作計畫或技術細節..."
                            value={pagesPlan}
                            onChange={e => setPagesPlan(e.target.value)}
                        />
                         {renderLinkButton(pagesPlan)}
                    </div>
                </div>
            </div>
        </form>

        <div className="p-4 border-t border-gray-100 bg-gray-50 flex flex-col-reverse md:flex-row justify-between items-center gap-3 md:gap-0 shrink-0 safe-area-bottom">
            <div className="w-full md:w-auto">
                {editingTicket && onDelete && (
                    <button 
                        type="button"
                        onClick={handleHideClick}
                        className={`w-full md:w-auto px-3 py-2 font-medium rounded-lg transition-colors flex items-center justify-center text-sm border border-transparent ${editingTicket.isHidden ? 'text-indigo-600 hover:bg-indigo-50 hover:border-indigo-100' : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'}`}
                    >
                        {editingTicket.isHidden ? (
                            <><Eye size={16} className="mr-1.5"/> 還原此單</>
                        ) : (
                            <><EyeOff size={16} className="mr-1.5"/> 隱藏此單</>
                        )}
                    </button>
                )}
            </div>
            <div className="flex space-x-3 w-full md:w-auto">
                <button 
                    type="button"
                    onClick={onClose}
                    className="flex-1 md:flex-none px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors text-center"
                >
                    取消
                </button>
                <button 
                    onClick={handleSubmit}
                    className="flex-1 md:flex-none px-6 py-2 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition-all text-center"
                >
                    {editingTicket ? '儲存變更' : '建立需求'}
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};