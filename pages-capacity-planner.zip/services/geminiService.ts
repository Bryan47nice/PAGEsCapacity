import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Helper to prevent calls if no key
const isConfigured = !!apiKey;

export const estimatePoints = async (title: string, description: string): Promise<{ points: number; reasoning: string }> => {
  if (!isConfigured) {
    return { points: 0, reasoning: "API Key missing. Please configure process.env.API_KEY." };
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const prompt = `
      You are a senior software engineer project manager.
      Analyze the following feature request for a UI Component Library.
      
      Title: ${title}
      Description: ${description}
      
      Estimate the complexity in "Story Points" using the Fibonacci sequence (1, 2, 3, 5, 8, 13, 21).
      - 1-2: Trivial text/style changes.
      - 3-5: Standard component features or small bug fixes.
      - 8-13: Complex new components or major refactors.
      - 21: Too big, needs splitting.
      
      Return ONLY a JSON object with this format:
      {
        "points": number,
        "reasoning": "short string explaining why"
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text);

  } catch (error) {
    console.error("Gemini Estimation Error:", error);
    return { points: 0, reasoning: "Failed to generate estimate. Please estimate manually." };
  }
};

export const refineDescription = async (rawInput: string): Promise<string> => {
  if (!isConfigured) return rawInput;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const prompt = `
      You are a product manager assistant.
      Rewrite the following feature request into a clear, concise "User Story" format with Acceptance Criteria.
      Keep it under 150 words.
      
      Input: ${rawInput}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || rawInput;
  } catch (error) {
    console.error("Gemini Refinement Error:", error);
    return rawInput;
  }
};